# FLSGuide

FLS Guide sebuah aplikasi berbasi mobile/android untuk para peserta Future Leader Summit, aplikasi FLS Guide adalah aplikasi mobile berbasis client server. 

## Spesifikasi Sistem
- API 15 (Minimal Android 4.0.1 Ice Cream Sandwitch)
- Android Studio
## Rancangan Sistem (Desain Awal)


## Fitur Aplikasi
- Greeting From Project Leader (sambutan Dari project Leader FLS)
- Acara yang sedang berlangsung
- Acara terdekat
- Rundown Acara (agenda)
- Informasi dari Panitia
- FAQ (pertanyaan septutar FLS yang sering ditanyakan)
- About Sistem

## Cara Install
- Silahkan download melalui branch `master`
- buka melalui `Android Studio` dan lakukan sinkronasi gradle
- silahkan debug aplikasi
- Download APK Aplikasi ? `Coming Soon`

## Lisensi
- MIT 

## Author
- @mnirfan
- @idindrakusuma
- @zaanfa

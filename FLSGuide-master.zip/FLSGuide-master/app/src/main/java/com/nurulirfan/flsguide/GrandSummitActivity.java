package com.nurulirfan.flsguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Zaanfa on 6/12/2017.
 */

public class GrandSummitActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.d_agenda_grandsummit);
    }
}
